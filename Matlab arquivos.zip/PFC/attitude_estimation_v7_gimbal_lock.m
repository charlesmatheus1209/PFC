function [phi_a, theta_a, psi_a] = attitude_estimation_v7_gimbal_lock(filename)
%
% Funcao para computar a orientacao para o rastreador
% a partir de dados dos acelerometros e do GPS.

% Variavel usada para depuracao do algoritmo.
% Ela estah declarada em todas as funcoes para que
% certas variaveis fiquem sempre visiveis.
% A unica variavel global.
global dbgdata;
dbgdata = [];
dbgdata.accel_dev = [];
dbgdata.theta_phi_n = -1;
dbgdata.state = [];
dbgdata.speed = [];
debug = 1;

if (debug)
    % Buffer para armazenar dados filtrados de aceleracao.
    % Somente para depuracao.
    dbgdata.accel_f_buffer = zeros(1000,3);
end

%% Inicializacao

if (nargin == 1),
    data = readtable(filename);
else
    data = loaddata;
end

% Troca os eixos de medicao para simular um 
% rastreador colocado na posicao vertical para cima,
% isto eh, theta = 90 graus.

%aux = data.eixox;
%data.eixox = data.eixoz;
%data.eixoz = -aux;

if (debug),
    if (nargin == 1),
        dbgdata.filename = filename;
    else
        dbgdata.filename = [];
    end
    
    dbgdata.data = data;
end
    
% Freq. GPS
fGPS = 1;

% Valor do vetor aceleracao da gravidade, no referencial
% do rastreador, quando o veiculo nao estah acelerado.
g_a = [0;0;1];
% g_a = [
%      2.885737089213201e-01;
%      3.650792059977115e-01;
%      8.648669293649267e-01];

% Valores iniciais esdruxulos para os angulos de orientacao
% do rastreador. Quando os valores de phi_a e theta_a 
% forem diferentes destes, se saberah que jah ocorreu
% pelo menos um processo de obtencao desses angulos.
phi_a = 1234;
theta_a = 1234;
psi_a = 1234;

% phi_a = -2.742162370450645e+00;
% theta_a = 2.927368377591862e-01;

% Limite inferior abaixo do qual nao se considera valido
% o dado GPS de velocidade (km/h)
vlow = 15*1;

% Limite acima do qual se considera que um evento de desvio
% significativo de aceleracao ocorreu (g).
ahigh = 0.1;%0.1 %Antes 0.22;

% Limite abaixo do qual se considera seguro avaliar a
% projecao da gravidade no referencial do rastreador
alow = 0.07;%0,07 %Antes 0.08; % Esse limite agora � um limite de desvio padr�o da acelera��o e n�o de acelera��o

% Filtro passa-baixas FIR com fase linear => atraso constante.
fc = 0.3;
fs = 20;
filter_order = 63;
filter_coeff = fir1(filter_order,fc/(fs/2));
filter_buffer = zeros(filter_order + 1,3);

if (debug),
    dbgdata.filter_buffer = filter_buffer;
end

% O atraso do processo de filtragem eh igual a 
% (filter_order/2)*(1/fs). Experimentalmente
% verificou-se um atraso entre a estimativa de 
% aceleracao via GPS e a aceleracao filtrada de:
GPS_filter_delay = 1.5;

% Numero de amostras, na taxa fs, que representam o atraso
% entre o GPS e os dados de aceleracao.
GPS_filter_delay_samples = ceil(GPS_filter_delay/(1/fs));

% Buffer onde se armazena os Ngps valores anteriores
% de velocidade sobre o solo e proa, oriundos do GPS,
% tal que durante todo o periodo o GPS estava valido.
% O buffer eh usado para computar a aceleracao do
% veiculo no referencial NED.
%
% O comprimento (numero de dados GPS) do buffer
% deve ser tal que represente o atraso no computo da aceleracao 
% filtrada + o intervalo maximo de tempo em que
% se espera observar toda o evento associado a um desvio
% significativo de aceleracao (um pico).
%
% Os dados armazenados em cada coluna sao:
%     Coluna 1: tempo RTC
%     Coluna 2: Vel. sobre o solo
%     Coluna 3: Proa (Heading)
%     Coluna 4: Height
%     Coluna 5: numero de amostras do acelerometro desde
%               a ultima aquisicao de dado GPS valido.

% Tempo maximo esperado para o desvio em (s).
max_duration_event = 10;

Ngps = ceil((GPS_filter_delay + max_duration_event)/(1/fGPS)) + 1;

GPS_buffer = zeros(Ngps,5);
gps_buffer_cont = 0;

if (debug),
    dbgdata.GPS_buffer = GPS_buffer;
end

% Numero de amostras desde a ultima aquisicao de dado
% GPS valido.
gps_nsamp = 0; 

% Indicador se estah ocorrendo um evento ou nao, com 
% base nos dados filtrados de aceleracao.
event = 0;

% Buffer para valores de aceleracao filtrados obtidos
% durante a ocorrencia de um evento 
% associado a um desvio
% significativo de aceleracao (um pico).
Naccel = ceil(max_duration_event/(1/fs));
Accel_buffer = zeros(Naccel,3);
accel_buffer_cont = 0;

if (debug),
    dbgdata.Accel_buffer = Accel_buffer;
end

% Buffer de valores de aceleracao para determinacao 
% da contribuicao da gravidade. Soh eh preenchido 
% depois da inicializacao do filtro.
Naccel_grav = 200;
Accel_buffer_grav = zeros(Naccel_grav,3);
accel_buffer_grav_cont = 0;

if (debug),
    dbgdata.Accel_buffer_grav = Accel_buffer_grav;
end

% Desvio maximo durante o evento.
max_accel_dev = 0;

% Instante do maximo durante o evento.
pos_max_accel_dev = 1;

% Esse laco reproduz a chegada sequencial de medicoes do acelerometro
% tri-axial e de dados do GPS.
for n = 1:length(data.contreg),
    
    if (debug),
       dbgdata.n = n; 
       
       %Registra o estado como estado 3 (Desconhecido)
       dbgdata.state(n) = 3;
    end
    
    % Preenche o buffer usado para calculo da saida do filtro
    % passa-baixas.
    filter_buffer(1:end-1,1:3) = filter_buffer(2:end,1:3);
    filter_buffer(end,:) = [data.eixox(n)/9.8,... // Adicionado para converter aceleração para G, sem utilizar a loaddata
                            data.eixoy(n)/9.8,...
                            data.eixoz(n)/9.8];                       
    
    if (debug),
       dbgdata.filter_buffer = filter_buffer; 
    end
                        
    % Aguarda a completa inicializacao do filtro FIR.
    if (n > filter_order)
            
        
        % Filtragem passa-baixas usando filtro FIR com atraso constante.
        accel_f = filter_coeff*filter_buffer;
        
        if (debug)
            dbgdata.accel_f_buffer(1:end-1,1:3) = dbgdata.accel_f_buffer(2:end,1:3);
            dbgdata.accel_f_buffer(end,1:3) = accel_f;
        end
       
        if (phi_a == 1234) || (theta_a == 1234)
            
            % Desvio de aceleracao
            
            mediax=0;
            mediay=0;
            mediaz=0;
            for i=1:64
                mediax=mediax+filter_buffer(i,1);
                mediay=mediay+filter_buffer(i,2);
                mediaz=mediaz+filter_buffer(i,3);
            end
            mediax=mediax/64;
            mediay=mediay/64;
            mediaz=mediaz/64;
            
            varx=0;
            vary=0;
            varz=0;
            for i=1:64
                varx=varx+(filter_buffer(i,1)-mediax)*(filter_buffer(i,1)-mediax);
                vary=vary+(filter_buffer(i,2)-mediay)*(filter_buffer(i,2)-mediay);
                varz=varz+(filter_buffer(i,3)-mediaz)*(filter_buffer(i,3)-mediaz);
            end
            varx=sqrt(varx/64);
            vary=sqrt(vary/64);
            varz=sqrt(varz/64);
                        
            accel_dev=(sqrt(varx*varx+vary*vary+varz*varz));
            

            if(debug)
                 dbgdata.accel_dev = [dbgdata.accel_dev; accel_dev];
            end

            %accel_dev = abs(sqrt((accel_f)*(accel_f')) - 1);
            if (accel_dev < alow)
                accel_buffer_grav_cont = accel_buffer_grav_cont + 1;
                Accel_buffer_grav(accel_buffer_grav_cont,:) = accel_f;
                
            % Eh preciso um intervalo continuo que atenda ao criterio
            % de baixa aceleracao.

                if (debug)
                    %Registra o estado como estado 1 (não acelerado)
                    dbgdata.state(n) = 1;
                end
            else
                accel_buffer_grav_cont = 0;
            end
            
            if (debug)
                dbgdata.Accel_buffer_grav = Accel_buffer_grav;
            end
            
            if (accel_buffer_grav_cont == Naccel_grav)
               
                [phi_a, theta_a, g_a] = Roll_Pitch_Estimation(Accel_buffer_grav);
                
                if (debug)
                    dbgdata.phi_a = phi_a;
                    dbgdata.theta_a = theta_a;
                    dbgdata.g_a = g_a;
                end
                
            end
            
        end
        
        % Somente analisa picos de desvio na aceleracao se 
        % os angulos de rolamento e arfagem jah tiverem sido obtidos.max_accel_dev
        if (phi_a ~= 1234) && (theta_a ~= 1234)
            
            % Desvio de aceleracao
            accel_dev = (accel_f - g_a');
            accel_dev = sqrt(accel_dev(1)^2 + accel_dev(2)^2 + accel_dev(3)^2);

            if(debug)
                 dbgdata.accel_dev = [dbgdata.accel_dev; accel_dev];
                 if(dbgdata.theta_phi_n == -1)
                    dbgdata.theta_phi_n = n;
                 end
            end
        
            if(n > 260)
               accel_dev;
            end

            if (accel_dev > ahigh)
                if (debug)
                    %Registra o estado como estado 2 (acelerado)
                    dbgdata.state(n) = 2;
                end
                % Inicio da deteccao de um pico.
                if (event == 0)
                    event = 1;
                    accel_buffer_cont = 1;
                else
                    accel_buffer_cont = accel_buffer_cont + 1;
                    
                    % Tamanho maximo de duracao de um evento de pico.
                    if (accel_buffer_cont > Naccel)
                        accel_buffer_cont = Naccel;
                    end
                    
                end
                
                % Buffer circular.
                Accel_buffer(1:end-1,:) = Accel_buffer(2:end,:);
                Accel_buffer(end,:) = accel_f;
                
                % Encontra o valor maximo dentro do evento de
                % pico.
                if (accel_dev > max_accel_dev)
                    max_accel_dev = accel_dev;
                    pos_max_accel_dev = accel_buffer_cont;
                end
                
                if (debug)
                   dbgdata.Accel_buffer = Accel_buffer; 
                end
                
            else
                
                % Fim do evento.
                if (event == 1)
                    
                    % Captura apenas os pontos de intreresse.
                    % Pode ser substituido pelo envio do buffer inteiro e
                    % do contador accel_buffer_cont para determinar dentro
                    % da funcao quais os dados de interesse.
                    short_accel_buffer = Accel_buffer(Naccel - accel_buffer_cont + 1: end,:);
                    
                    psi_a_est = Yaw_Estimation(phi_a,theta_a,g_a,...
                        GPS_filter_delay,...
                        fs,...
                        GPS_buffer,gps_buffer_cont,gps_nsamp,...
                        short_accel_buffer,...
                        max_accel_dev, pos_max_accel_dev);
                    
                    if (psi_a_est ~= 1234)
                        psi_a = psi_a_est;
                    end
                        
                    
                    % Se os ultimos valores do buffer GPS foram invalidos,
                    % zera o buffer apos a ocorrencia do evento.
                    if (gps_buffer_cont > 0)
                        if (GPS_buffer(gps_buffer_cont,3) == 1234),
                            gps_buffer_cont = 0;
                        end
                    end
                    
                end
                
                event = 0;
                
                max_accel_dev = 0;
                pos_max_accel_dev = 1;
            end
            
        end
        
        %%
        
        % Coleta dados GPS necessarios para se estimar
        % a aceleracao no referencial NED.
        % Note que se trabalha com dados GPS antigos, em funcao
        % do atraso existente entre os dados de GPS e a 
        % saida do filtro passa-baixas dos sinais de aceleracao.
        
        m = n - GPS_filter_delay_samples;
        
        if (debug)
            dbgdata.m = m;
        end
        
        if ((data.gps_fix(m) == 3) && (data.gps_speed(m) >= vlow))
            
            if (gps_buffer_cont == 0)
                                
                % Amostra o dado GPS de interesse
                GPS_buffer(gps_buffer_cont+1,1) = data.gps_rtc(m);
                GPS_buffer(gps_buffer_cont+1,2) = data.gps_speed(m);
                GPS_buffer(gps_buffer_cont+1,3) = data.gps_direction(m);
                GPS_buffer(gps_buffer_cont+1,4) = data.gps_alt(m);
                GPS_buffer(gps_buffer_cont+1,5) = 0;
                gps_nsamp = 0;
           
                if (debug)
                    dbgdata.GPS_buffer = GPS_buffer;
                end
                
                gps_buffer_cont = gps_buffer_cont+1;
                
            elseif (data.gps_rtc(m) ~= GPS_buffer(gps_buffer_cont,1))
                               
                % Buffer rotativo de tamanho fixo.
                % Roda o buffer.
                if (gps_buffer_cont == Ngps)
                    GPS_buffer(1:end-1,:) = GPS_buffer(2:end,:);
                    gps_buffer_cont = Ngps-1;
                end
                
                % Amostra o dado GPS de interesse
                GPS_buffer(gps_buffer_cont+1,1) = data.gps_rtc(m);
                GPS_buffer(gps_buffer_cont+1,2) = data.gps_speed(m);
                GPS_buffer(gps_buffer_cont+1,3) = data.gps_direction(m);
                GPS_buffer(gps_buffer_cont+1,4) = data.gps_alt(m);
                GPS_buffer(gps_buffer_cont+1,5) = gps_nsamp;
                gps_nsamp = 0;
                
                gps_buffer_cont = gps_buffer_cont+1;
                
                if (debug)
                    dbgdata.GPS_buffer = GPS_buffer;
                end
                
            end
            
        else
            % Se a seq. de mensagens eh interrompida, inicia-se
            % nova tentativa. Isso eh postergado se se estiver
            % avaliando um evento de pico de aceleracao.
            if (event == 0)
                
                gps_buffer_cont = 0;
                
            elseif (gps_buffer_cont > 0)
                
                if (data.gps_rtc(m) ~= GPS_buffer(gps_buffer_cont,1)),
                
                    % Buffer rotativo de tamanho fixo.
                    % Roda o buffer.
                    if (gps_buffer_cont == Ngps)
                        GPS_buffer(1:end-1,:) = GPS_buffer(2:end,:);
                        gps_buffer_cont = Ngps-1;
                    end
                    
                    % Marca o dado com uma direcao esdruxula.
                    GPS_buffer(gps_buffer_cont+1,1) = data.gps_rtc(m);
                    GPS_buffer(gps_buffer_cont+1,2) = 0;
                    GPS_buffer(gps_buffer_cont+1,3) = 1234;
                    GPS_buffer(gps_buffer_cont+1,4) = 1234;
                    GPS_buffer(gps_buffer_cont+1,5) = gps_nsamp;
                    gps_nsamp = 0;
                    
                    gps_buffer_cont = gps_buffer_cont+1;
                    
                    if (debug)
                        dbgdata.GPS_buffer = GPS_buffer;
                    end
                    
                end
                
            end
        end
        
        gps_nsamp = gps_nsamp+1;
        
        if (debug)
           dbgdata.GPS_buffer = GPS_buffer; 
        end
        
    end
end


function [phi_a, theta_a, an] = Roll_Pitch_Estimation(accel_buffer)
% Medias dos valores estimados para rolamento e arfagem, usando
% o algoritmo em que isso eh feito quando a norma da aceleracao estah 
% muito proxima de 1 (veiculo parado ou quase parado, ou em movimento 
% retilineo uniforme). 
%
% Note que o acelerometro, nesta condicao, medirah 
% 
%   am = axyz - g, com axyz = 0 =>  am = -g.
%
% Note tambem que a transformacao abaixo limita theta entre +/- pi/2.

% Variavel global de depuracao
global dbgdata;

% Usa a media das aceleracoes filtradas.
% Garante que o vetor tem norma unitaria. 
an = mean(accel_buffer(:,1:3));
an = an'/(sqrt(an*an'));

phi_a = atan2(-an(2),-an(3));
theta_a = asin(an(1));

disp(['phi_a = ',num2str(phi_a*180/pi),' deg. theta_a = ',num2str(theta_a*180/pi)]);

function psi_a = Yaw_Estimation(phi_a, theta_a, g_a,...
                                filter_delay,...
                                fs,...
                                GPS_buffer,gps_buffer_cont,gps_nsamp,...
                                Accel_buffer,...
                                max_accel_dev, pos_max_accel_dev)
    
                            
% Variavel global de depuracao
global dbgdata;
                            
psi_a = 1234;
                            
if (gps_buffer_cont == 0)
    % Sem sucesso. O buffer GPS estah vazio.
    return;
end
                            
% Encontra o ultimo ponto GPS dentro do 
% intervalo de tempo do evento de pico,
% portanto cujo instante de tempo de ocorrencia
% eh anterior ao final do evento. 
% Nao contabiliza dados invalidos no buffer GPS
% que foram ali colocados porque se estava avaliando
% um evento de pico.

% Descontando o atraso do filtro FIR.
% ntotal = ceil(filter_delay/(1/fs));

ntotal = 0;
end_gps = gps_buffer_cont;
nsamples = gps_nsamp;
% while ((nsamples < ntotal) || (GPS_buffer(end_gps,3) == 1234)),
% 
%     nsamples = nsamples + GPS_buffer(end_gps,5); 
%     
%     if (end_gps > 0),
%         end_gps = end_gps - 1;
%     else
%         return;
%     end
%     
% end

% A partir do conhecimento do ultimo ponto GPS que pertence
% ao intervalo do evento, recalcula as posicoes dos dados GPS
% em relacao ao buffer Accel_buffer.
event_length = size(Accel_buffer,1);
k = end_gps;
last_sample = event_length - (nsamples - ntotal);
while ((last_sample > 0) && (k > 0))
    aux = last_sample - GPS_buffer(k,5);
    GPS_buffer(k,5) = last_sample;
    last_sample = aux;
    k = k - 1;
end

if (k < end_gps)
    start_gps = k + 1;
else
    start_gps = end_gps;
end

% Mantem apenas os pontos no interior do evento.
GPS_buffer = GPS_buffer(start_gps:end_gps,:);

% Impossivel continuar se houver apenas 1 ponto. 
% Eh preciso pelo menos dois valores de GPS para
% calcular a derivada por diferenca finita.
if (size(GPS_buffer,1) == 1)
    return;
end

% yaw_variation = max(GPS_buffer(:,3)) - min(GPS_buffer(:,3));
% alt_variation = max(GPS_buffer(:,4)) - min(GPS_buffer(:,4));

% Variacao total do angulo de guinada.
% Esse calculo precisa ser realizado com cuidado, pois
% os angulos de proa informados pelo receptor GPS estao
% entre 0 e 360 graus e, na verdade, um angulo de 
% 358 graus e outro de 2 graus estao distantes apenas por 4 graus.
%
% Aproveita-se e calcula-se aqui a variacao maxima da altitude.
min_alt = 1e6;
max_alt = -1e6;
yaw_variation = 0;
for k = 1:size(GPS_buffer,1)

    if (k ~= 1)
        % Subtrai 2 vetores sobre o circulo de raio unitario.
        v1 = [cos(GPS_buffer(k-1,3)*pi/180);sin(GPS_buffer(k-1,3)*pi/180)];
        v2 = [cos(GPS_buffer(k,3)*pi/180);sin(GPS_buffer(k,3)*pi/180)];
        vr = v2 - v1;
        
        % O comprimento do vetor diferenca, dividido por 2, eh o cateto oposto
        % ao angulo metade que indica a diferenca angular entre os dois
        % vetores.
        delta_yaw = 2*asin(sqrt(vr(1)^2 + vr(2)^2)/2);
        
        yaw_variation = yaw_variation + delta_yaw;
    end
    
    if (GPS_buffer(k,4) > max_alt)
        max_alt = GPS_buffer(k,4);
    end
    
    if (GPS_buffer(k,4) < min_alt)
        min_alt = GPS_buffer(k,4);
    end
end

% Variacao total da altitude.
alt_variation = max_alt - min_alt;

% Variacao media da guinada ao longo do tempo.
yaw_variation = yaw_variation*180/pi;

% Calcula os valores de aceleracao no referencial
% NED, usando diferenca finita, para todos os
% pontos dentro do intervalo do evento de pico.
[axyz,psi_v] = accel_GPS(GPS_buffer);

% % Encontra o valor de aceleracao mais alto em axyz,
% % e o valor correspondente em Accel_buffer.
% [~,idx] = max(axyz(:,1).^2 + axyz(:,2).^2 + axyz(:,3).^2);
% axyz = axyz(idx,:);
% axyz = axyz';
% psi_v = psi_v(idx);
% 
% am = Accel_buffer(GPS_buffer(idx,4),:)';
% 
% R_phi = [ 1,          0,          0;
%           0, cos(phi_a), sin(phi_a);
%           0,-sin(phi_a), cos(phi_a)];
%       
% R_theta = [ cos(theta_a), 0,-sin(theta_a);
%                        0, 1, 0;
%             sin(theta_a), 0, cos(theta_a)];
%        
% w = (R_theta')*(R_phi')*(am - g_a);
% 
% R_psi = [ cos(psi_v), sin(psi_v),  0;
%          -sin(psi_v), cos(psi_v),  0;
%                    0,          0,  1];
% 
% v = R_psi*axyz;
% 
% % Note que a 3a componente nao importa. Por isso o calculo
% % de w acima pode ser simplificado.
% psi_a = atan2(v(2)*w(1) - v(1)*w(2), v(1)*w(1) + v(2)*w(2));

R_phi = [ 1,          0,          0;
          0, cos(phi_a), sin(phi_a);
          0,-sin(phi_a), cos(phi_a)];

R_theta = [ cos(theta_a), 0,-sin(theta_a);
                       0, 1, 0;
            sin(theta_a), 0, cos(theta_a)];
    
    am = Accel_buffer(GPS_buffer(:,5),:);
    
%     am = Accel_buffer(pos_max_accel_dev,:);
%     w = (R_theta')*(R_phi')*((am - g_a')');
    
    axyz = axyz';
    psi_a = [];
    residuo = [];
    for k = 1:size(axyz,2)
        
        R_psi = [ cos(psi_v(k)), sin(psi_v(k)),  0;
                 -sin(psi_v(k)), cos(psi_v(k)),  0;
                           0,          0,  1];
                       
        w = (R_theta')*(R_phi')*((am(k,:) - g_a')');                 
        v = R_psi*(axyz(:,k));
        
        % Note que a 3a componente nao importa. Por isso o calculo
        % de w acima pode ser simplificado.
        psi_a = [psi_a; atan2(v(2)*w(1) - v(1)*w(2), v(1)*w(1) + v(2)*w(2))];
        
        R_psi_a = [ cos(psi_a(end)), sin(psi_a(end)),  0;
                   -sin(psi_a(end)), cos(psi_a(end)),  0;
                           0,          0,              1];
        
        vetor_residuo = (am(k,:) - g_a')' -  (R_phi*R_theta*R_psi_a*R_psi*(axyz(:,k)));
                       
        
        
        
        
        
        residuo = [residuo; sqrt(vetor_residuo'*vetor_residuo)];
        
    end

    residuo = mean(residuo);
    psi_a = mean(psi_a);
    
    R_psi_a = [ cos(psi_a(end)), sin(psi_a(end)),  0;
               -sin(psi_a(end)), cos(psi_a(end)),  0;
                       0,          0,              1];

% w = w/(sqrt(w'*w));
% v = [1;0;0];
% 
% psi_a = atan2(v(2)*w(1) - v(1)*w(2), v(1)*w(1) + v(2)*w(2));

%disp(['phi_a = ',num2str(phi_a*180/pi),' deg. theta_a = ',num2str(theta_a*180/pi)]);

if ((size(GPS_buffer,1) > 2) && (residuo < 0.2))
        
    
    disp(['psi_a = ',num2str(psi_a*180/pi,2),' deg.  Yaw var.: ',num2str(yaw_variation,4),' deg. Altitude var. ',num2str(alt_variation,2) ' m GPS RTC: ', num2str(GPS_buffer(1,1)), ' Residuo: ', num2str(residuo,4),' Num. pts. GPS: ',num2str(size(GPS_buffer,1))]);
    
    
    % Para corrigir os valores de aceleracao fornecidos por um
    % rastredor n�o alinhado com o carro, basta multiplicas o vetor
    % original pela matriz R_final:
    % a_corrigido=R_final*a_original
    % onde a_original e um vetor coluna com tres elementos [ax; ay; az]
    R_final=(R_phi*R_theta*R_psi_a)'
    
    
else
    
   psi_a=1234;
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [axyz,psi_v] = accel_GPS(GPS_buffer)

% Variavel global de depuracao
global dbgdata;

Ngps = size(GPS_buffer,1);

vxy = zeros(Ngps,2);

t = [GPS_buffer(:,1), GPS_buffer(:,1)];

% Note que o angulo de proa estah em graus e a velocidade em km/h.
% Converte-se aqui para rad e m/s.
vxy(:,1) = GPS_buffer(:,2)*1000/3600.*cos(GPS_buffer(:,3)*pi/180);
vxy(:,2) = GPS_buffer(:,2)*1000/3600.*sin(GPS_buffer(:,3)*pi/180);

% Valor padrao para a gravidade.
g0 = 9.80665;

% Estimativa via diferenca finita dos valores nos extremos do 
% buffer de dados validos GPS.
axyz = (diff(vxy)./diff(t))*(1/g0);

% Considera-se neste calculo que o veiculo estah no plano e, por isso,
% az = 0.
axyz = [axyz,zeros(size(axyz,1),1)];  

% Obtem os angulos correspondentes de proa
psi_v = atan2(vxy(1:end-1,2),vxy(1:end-1,1));















