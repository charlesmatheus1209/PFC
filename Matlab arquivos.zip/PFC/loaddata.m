function data = loaddata(filename)
%
% data = loaddata
%
% Loads the test files, and if no return value is specified, displays 
% the corresponding data.
%
% Multiple files can be loaded at the same time: just select more than one
% file holding the CTRL or SHIFT keys.
%
% Last update: November, 03, 2014.
 
pathname = [];
 
if (nargin == 0),
    [filename, pathname, ~] = uigetfile(...
        '*.TXT',...
        'Selecione um arquivo de dados TXT',...
        'C:\\Users\\Glaydstone\\Desktop\\Teste Campo','Multiselect','on');
end
 
data.contreg = [];
data.eixox = [];
data.eixoy = [];
data.eixoz = [];
data.gps_direction = [];
data.gps_speed = [];
data.gps_fix = [];
data.gps_nsats = [];
data.gps_lat = [];
data.gps_long = [];
data.gps_alt = [];
data.gps_pdop = [];
data.gps_hdop = [];
data.gps_tlf = [];  % Tempo decorrido desde o ultimo fix.
data.gps_rtc = [];
data.gps_rtc2 = [];
data.sentido = [];
 
if iscellstr(filename),  % Varios arquivos foram selecionados
    nfiles = length(filename);
    files = ordena(filename);
else % Apenas um arquivo foi selecionado, ou foi cancelada a acao.
    if (isstr(filename)),
        nfiles = 1;
        files{1} = filename;
    else
        nfiles = 0;
        files{1} = '';
    end
end
 
for k = 1:nfiles,
    fid = fopen([pathname,files{k}]);
    dados = textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s %s',[20,inf]);
    fclose(fid);
    contreg = dados{1};
    % Verifica se algum dado foi lido. As vezes ha arquivos vazios.
    if (~isempty(contreg)),
        eixox = dados{2};
        eixoy = dados{3};
        eixoz = dados{4};
        gps_direction = dados{9};
        gps_speed = dados{10};
        gps_fix = dados{11};
        gps_nsats = dados{12};
        % gps_lat = char(dados{13});
        % gps_long = char(dados{14});
        gps_lat = dados{13};
        gps_long = dados{14};
        gps_alt = dados{15};
        gps_pdop = dados{16};
        gps_hdop = dados{17};
        gps_tlf = dados{18};
        gps_rtc = char(dados{19});
        gps_rtc2 = char(dados{20});
 
        subida = dados{5};
        descida = dados{6};
        clear dados;
        % Contador de amostras
        if k == 1,
            startcont = contreg(1);
        else
            startcont = data.contreg(end) + 1;
        end
        data.contreg = [data.contreg;contreg + startcont];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Dados do acelerometro em (G x 1000). Sao convertidos aqui para G
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        data.eixox = [data.eixox;eixox/1000];
        data.eixoy = [data.eixoy;eixoy/1000];
        data.eixoz = [data.eixoz;eixoz/1000];
        %%%%%%%%%%%%%%
        % Dados do GPS
        %%%%%%%%%%%%%%
        % Direcao sobre a terra em (GRAUS x 100). Sao convertidos aqui para GRAUS.
        data.gps_direction = [data.gps_direction;gps_direction/100];
        % Velocidade GPS (KM/H x 100). Sao convertidos aqui para KM/H.
        data.gps_speed = [data.gps_speed;gps_speed/100];
        % Estado de FIX (0 = GPS invalido, caso contrario GPS valido)
        % Aparecem varios numeros/codigos diferentes de 1
        % neste campo.
        data.gps_fix = [data.gps_fix; gps_fix];
        % Numero de Satelites
        data.gps_nsats = [data.gps_nsats; gps_nsats];
 
        sentido = descida + subida;
        data.sentido = [data.sentido; sentido];
        % Latitude GGMM.MMMM. Aqui convertido para *radianos*.
        degrees = zeros(length(gps_lat),1);
        minutes = zeros(length(gps_lat),1);       
        % O trecho abaixo foi usado quando se considerava
        % Latitude e Longitude como strings.
        % Mas alguns arquivos de dados nao respeitavam o
        % comprimento esperado para a string, produzindo
        % valores de retorno invalidos para str2num.
        %     idx =  find(gps_lat(:,1) == '-');
        %     if ((~isempty(idx)) && (size(gps_lat,2) > 3)),
        %         degrees(idx) = str2num(gps_lat(idx,1:3));
        %         minutes(idx) = str2num(gps_lat(idx,4:end))*1e-4;
        %     end
        %
        %     idx =  find(gps_lat(:,1) ~= '-');
        %     if ((~isempty(idx)) && (size(gps_lat,2) > 2)),
        %         degrees(idx) = str2num(gps_lat(idx,1:2));
        %         minutes(idx) = str2num(gps_lat(idx,3:end))*1e-4;
        %     end
        %     gps_lat = sign(degrees).*(abs(degrees) + minutes/60)*pi/180;
        degrees = fix(gps_lat/1e6);
        minutes = (gps_lat/1e6 - degrees)*1e2;
        gps_lat = (degrees + minutes/60)*pi/180;
        data.gps_lat = [data.gps_lat; gps_lat];
        % Longitude GGMM.MMMM. Aqui convertido para *radianos*.
        degrees = zeros(length(gps_long),1);
        minutes = zeros(length(gps_long),1);
        % O trecho abaixo foi usado quando se considerava
        % Latitude e Longitude como strings.
        % Mas alguns arquivos de dados nao respeitavam o
        % comprimento esperado para a string, produzindo
        % valores de retorno invalidos para str2num.
        %     idx =  find(gps_long(:,1) == '-');
        %     if ((~isempty(idx)) && (size(gps_long,2) > 3)),
        %         degrees(idx) = str2num(gps_long(idx,1:3));
        %         minutes(idx) = str2num(gps_long(idx,4:end))*1e-4;
        %     end
        %
        %     idx =  find(gps_long(:,1) ~= '-');
        %     if ((~isempty(idx)) && (size(gps_long,2) > 2)),
        %         degrees(idx) = str2num(gps_long(idx,1:2));
        %         minutes(idx) = str2num(gps_long(idx,3:end))*1e-4;
        %     end
        %     gps_long = sign(degrees).*(abs(degrees) + minutes/60)*pi/180;
        degrees = fix(gps_long/1e6);
        minutes = (gps_long/1e6 - degrees)*1e2;
        gps_long = (degrees + minutes/60)*pi/180;
        data.gps_long = [data.gps_long; gps_long];
        % Altitude x 100. Convertida para metros.
        data.gps_alt = [data.gps_alt; gps_alt/100];
        % PDOP x 100. Fator de normalizacao eliminado.
        data.gps_pdop = [data.gps_pdop; gps_pdop/100];
        % HDOP x 100. Fator de normalizacao eliminado.
        data.gps_hdop = [data.gps_hdop; gps_hdop/100];
        % AGE = Tempo decorrido desde o ultimo FIX
        data.gps_tlf = [data.gps_tlf; gps_tlf];
        % Data Hora do RTC, corrigido pelo GPS.
        % Aqui se converte para tempo em segundos
        % desde o inicio do experimento.
        if ~isempty(gps_rtc), %ddMMyyHHmmss
            hours = str2num(gps_rtc(:,7:8));
            minutes = str2num(gps_rtc(:,9:10));
            seconds = str2num(gps_rtc(:,11:12));
            gps_rtc = hours*3600 + minutes*60 + seconds;
            if (k == 1),
                experiment_start_time = gps_rtc(1);
            end
            % Eliminamos a correcao para que o tempo RTC
            % sempre comece de zero.
            % gps_rtc = gps_rtc - experiment_start_time;
            data.gps_rtc = [data.gps_rtc; gps_rtc];
        end
         % Segundo contador RTC
        if ~isempty(gps_rtc2),
            hours = str2num(gps_rtc2(:,7:8));
            minutes = str2num(gps_rtc2(:,9:10));
            seconds = str2num(gps_rtc2(:,11:12));
            gps_rtc2 = hours*3600 + minutes*60 + seconds;
            if (k == 1),
                experiment_start_time2 = gps_rtc2(1);
            end
            gps_rtc2 = gps_rtc2 - experiment_start_time2;
            data.gps_rtc2 = [data.gps_rtc2; gps_rtc2];
        end
    end
end
 
if ((nargout == 0) && (nfiles > 0)),
    if nfiles == 1,
        figure('Name',[pathname,files{1}],'NumberTitle','off','Color',[0.95 1 1]);
    else
        figure('Name',[pathname,files{1},' to ',files{end}],'NumberTitle','off','Color',[0.95 1 1]);
    end
    axes(1) = subplot(5,1,1);
    plot(data.contreg,data.eixox);
    ylabel('a_x (g)');
    title('Eixo x do acelerometro');
    grid on;
    axes(2) = subplot(5,1,2);
    plot(data.contreg,data.eixoy);
    ylabel('a_y (g)');
    title('Eixo y do acelerometro');
    grid on;
    axes(3) = subplot(5,1,3);
    plot(data.contreg,data.eixoz);
    ylabel('a_z (g)');
    title('Eixo z do acelerometro');
    grid on;
    axes(4) = subplot(5,1,4);   
    plot(data.contreg,data.gps_direction);
    ylabel('direcao (graus)');
    title('GPS: direcao sobre a terra');
    grid on;
    axes(5) = subplot(5,1,5);
    plot(data.contreg,data.gps_speed);
    ylabel('Velocidade (km/h)');
    title('GPS: velocidade');
    grid on;
    xlabel('Numero da amostra');
    linkaxes(axes,'x');
end
 
end
 
% Recebe um vetor de celulas com strings e as ordena.
function files = ordena(filename)
 
    files = sort(filename);
 
end